from .models import *
from django.db.models.signals import post_save
from django.dispatch import receiver


@receiver(post_save, sender=Alumno)
def crear_calificaciones(sender, instance, **kwargs):
    criterios_evaluacion = CriterioEvalUD.objects.all()

#No se que hacer
    
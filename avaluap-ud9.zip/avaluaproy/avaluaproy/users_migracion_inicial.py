from django.db import migrations, models
from usuarios.models import *

#9.3.c MIGRACIONES USERS

def migracion_user():

    user = MyUser.objects.create(username='ejemplo', email='ejemplo@ejemplo.com', activo=True, create_date='', update_date='', is_staff=False, is_active=True)










class Migration(migrations.Migration):

    dependencies = [('usuarios', '0001_initial')]

    operations = [
        migrations.RunPython(migracion_user),
            ]

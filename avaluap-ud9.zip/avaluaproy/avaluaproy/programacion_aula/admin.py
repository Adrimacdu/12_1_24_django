from django.contrib import admin
from .models import *
# Register your models here.

#UD9.4 Admin para crear alumnos, habria que hacer los otros para cada modelo pero no se pide en la practica

class ModAlumno(admin.ModelAdmin):
                                             
    list_display= ['nombre', 'apellidos', 'ciudad', 'codigo_postal', 'direccion'] 
    list_display_links= ['ciudad', 'nombre']
    search_fields= ['ciudad', 'nombre']
    readonly_fields= ['id']


class ModCriterioEvalUD(admin.ModelAdmin):

    list_display= ['unidad', 'criterio_evaluacion'] 
    list_display_links= ['unidad', 'criterio_evaluacion'] 
    search_fields= ['unidad', 'criterio_evaluacion'] 
    readonly_fields= ['id']
    


admin.site.register(Alumno, ModAlumno)
admin.site.register(CriterioEvalUD, ModCriterioEvalUD)